"use strict";

import path from 'path';
import http from 'http';
import dotenv from 'dotenv';
import express from 'express';
import createError from 'http-errors';
import config from './config/key/app/app.config';
import { goodBye } from './app/utils/http.helper';
import bootstrapConfig from './bootstrap/app.main';
import { runWorker } from './app/worker/index.worker';
import redisConnection from './config/db/redis.config';
import { connectPgsql } from './config/db/pgsql.config';
import { DEV_ENV } from './app/constants/common.constant';
import { NOT_FOUND, INTERNAL_SERVER_ERROR } from './app/constants/error.constant';
/*
|--------------------------------------------------------------------------
| EXPRESS SERVER CONFIG
|--------------------------------------------------------------------------
*/
dotenv.config();
const app = express();
const server = http.createServer(app);
const HTML_FILE = path.join(__dirname, 'index.html');
/*
|--------------------------------------------------------------------------
| RENDER APPLICATION PING INDEX
|--------------------------------------------------------------------------
*/
app.get('/', (req, res) => {
	res.sendFile(HTML_FILE);
});
/*
|--------------------------------------------------------------------------
| DATABASE & EXPRESS JS CONNECTION
|--------------------------------------------------------------------------
*/
Promise.resolve(redisConnection);
connectPgsql();
bootstrapConfig(app);
/*
|--------------------------------------------------------------------------
| CATCH 404 AND FORWARD TO ERROR HANDLER
|--------------------------------------------------------------------------
*/
app.use(function (request, response, next) {
  next(createError(NOT_FOUND));
});
/*
|--------------------------------------------------------------------------
| ERROR HANDLER FOR INTERNAL SERVER ERROR & NOT FOUND & OTHER ERRORS
|--------------------------------------------------------------------------
*/
app.use(function (error, request, response, next) {
  const APP_ENV = request.app.get("env");
  const ISDEVENV = APP_ENV === DEV_ENV;
  response.locals.message = error.message;
  response.locals.error = ISDEVENV ? error : {};
  if (error.status === NOT_FOUND) {
    return goodBye(response, NOT_FOUND, error.message, []);
  }
  return goodBye(response, (error.status || INTERNAL_SERVER_ERROR ), error.message, []);
});
/*
|--------------------------------------------------------------------------
| CREATE SERVER PORT
|--------------------------------------------------------------------------
*/
const startServer = () => {
	server.listen(config.server.port, config.server.ip, () => {
		console.log('Express server listening on ', server.address().port);
	});
};

setImmediate(startServer);
setTimeout(runWorker, 1000);

export default app;
