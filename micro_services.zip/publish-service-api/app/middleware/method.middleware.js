"use strict";

import compose from 'composable-middleware';
import { goodBye } from '../utils/http.helper';
import { METHOD_NOT_ALLOWED } from "../constants/error.constant";
import { METHOD_INVALID } from "../constants/error-message.constant";

export const methodMiddleware = methods => {
    return compose().use(async (request, response, next) => {
        try {
          if (!methods.includes(request.method)) {
            return goodBye(
              response,
              METHOD_NOT_ALLOWED,
              METHOD_INVALID,
              []
            );
          }
          next();
        } catch (error) {
          next(new Error(`METHOD MIDDLEWARE : methodMiddleware Method : ${err}`));
        }
    });
};