"use strict";

import compose from 'composable-middleware';
import { goodBye } from '../utils/http.helper';
import JwtProvider from "../providers/jwt.provider";
import { jwtOptions } from '../../config/library/jwt.config';
import { INVALID_ACCESS } from '../constants/error-message.constant';
import { UNAUTHORIZED, FORBIDDEN } from "../constants/error.constant";

export const authMiddleware = () => {
    return compose().use(async (request, response, next) => {
        try {
            const authHeader = request.header("Authorization");
            const token = authHeader && authHeader.split(" ")[1];
            if (!token || request.logout.has(token)) {
              return goodBye(
                response,
                UNAUTHORIZED,
                INVALID_ACCESS,
                []
              );
            }
            const jwtAuthProvider = new JwtProvider();
            const userDetails = jwtAuthProvider.verify(token, jwtOptions);
            if (!userDetails) {
              return goodBye(
                response,
                FORBIDDEN,
                INVALID_ACCESS,
                []
              );
            }
            request.user = userDetails;
            next();
        } catch (error) {
          next(new Error(`AUTH MIDDLEWARE : authMiddleware Method : ${error}`));
        }
    });
};