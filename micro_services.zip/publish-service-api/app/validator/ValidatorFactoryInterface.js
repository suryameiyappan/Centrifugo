"use strict";

class ValidatorFactoryInterface {
  /**
   * @param {object} request
   * @param {string} service
   *
   * @return {object}
   */
  async run(request, service) {
    throw new Error(
      'ValidatorFactoryInterface : Subclasses must implement the "run" method'
    );
  }
}

export default ValidatorFactoryInterface;
