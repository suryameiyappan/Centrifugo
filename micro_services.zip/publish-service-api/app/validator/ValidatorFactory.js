"use strict";

import { serviceValidator } from "../utils/validator.helper";
import ValidatorFactoryInterface from "./ValidatorFactoryInterface";


class ValidatorFactory extends ValidatorFactoryInterface {
  /*
  |--------------------------------------------------------------------------
  | RUN SERVICE VALIDATOR
  |--------------------------------------------------------------------------
  */
  async run(request, service) {
    return await serviceValidator(request, service);
  }
}

export default ValidatorFactory;
