const Joi = require('joi');

class GoogleValidation {
    /*
    |---------------------------------------
    | CREATE GOOGLE LOGIN VALIDATOR RULES
    |---------------------------------------
    */
    googleLogin(request) {
        const schema = Joi.object({
            name: Joi.string().min(3).required(),
            firstName: Joi.string().min(3).required(),
            lastName: Joi.string().min(3).required(),
            email: Joi.string().email().required(),
            id: Joi.string().required(),
            idToken: Joi.string().required(),
            photoUrl: Joi.string().required(),
            provider: Joi.string().required()
        });
        return schema.validate(request).error;
    }
  }
  
module.exports = new GoogleValidation();