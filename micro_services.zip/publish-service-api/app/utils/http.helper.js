"use strict";

export const goodBye = (response, statusCode, message, resData = {}) => {
    response.status(statusCode).json({
      code: statusCode,
      data: resData,
      message: message,
      status: (statusCode === 200 || statusCode === 201) ? true : false
    });
};