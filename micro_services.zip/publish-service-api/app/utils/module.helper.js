"use strict";

import { loadFactory } from '../../config/factory/modules.config';
import { SUB_PRODUCT_ROUTES } from '../constants/modules.constant';

/*
|--------------------------------------------------------------------------
| GET Module OBJECT
|--------------------------------------------------------------------------
*/
export const getModuleObject = async (request) => {
  const { module_code, action, module } = request.body;
  const moduleClass = (await loadFactory(module_code, SUB_PRODUCT_ROUTES));
  
  if (!moduleClass) {
    throw new Error(`${module} Module: Module code ${module_code} class not found`);
  }
  const moduleInstance = (new moduleClass());

  if (!moduleInstance[action]) {
    throw new Error(`${module} Module: Module ${module_code} class method ${action} not found`);
  }

  return moduleInstance;
};
