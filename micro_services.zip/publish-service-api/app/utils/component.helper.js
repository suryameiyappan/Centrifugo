"use strict";

import { loadFactory } from '../../config/factory/modules.config';
import { SUB_PRODUCT_ROUTES } from '../constants/modules.constant';

/*
|--------------------------------------------------------------------------
| GET COMPONENT OBJECT
|--------------------------------------------------------------------------
*/
export const getComponentObject = async (request) => {
  const { component_code, action, component } = request.body;
  const componentClass = (await loadFactory(component_code, SUB_PRODUCT_ROUTES));
  
  if (!componentClass) {
    throw new Error(`${component} Component :component code ${component_code} class not found`);
  }
  const componentInstance = (new componentClass());

  if (!componentInstance[action]) {
    throw new Error(`${component} Module: Module ${component_code} class method ${action} not found`);
  }

  return componentInstance;
};
