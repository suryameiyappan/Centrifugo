"use strict";

import { v4 as uuidv4 } from 'uuid';

/*
|--------------------------------------------------------------------------
| HELPER METHOD
|--------------------------------------------------------------------------
*/
export const generateToken = (length) => {
  let result = '';
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const charactersLength = characters.length;

  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
};

export const generateUniqueId = (prefix = 'x') => {
  const timestamp = Date.now();
  const randomPart = Math.floor(Math.random() * 10000);
  return `${prefix}${timestamp}${randomPart}`;
};

export const generateApiKey = () => {
  return uuidv4();
};
