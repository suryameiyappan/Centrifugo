"use strict";

import { VALIDATOR_CONFIG } from "../constants/modules.constant";
import { loadFactory } from "../../config/factory/modules.config";

/*
|--------------------------------------------------------------------------
| HELPER METHOD FOR VALIDATION
|--------------------------------------------------------------------------
*/
export const validator = async (request) => {
    const validator = (await loadFactory(request.body.module_code, VALIDATOR_CONFIG));
    return validator[request.body.action](request.body.data);
};
/*
|--------------------------------------------------------------------------
| HELPER METHOD FOR VALIDATION
|--------------------------------------------------------------------------
*/
export const serviceValidator = async (request, service) => {
    const validator = (await loadFactory(service, VALIDATOR_CONFIG));
    return validator.validation(request.body);
};