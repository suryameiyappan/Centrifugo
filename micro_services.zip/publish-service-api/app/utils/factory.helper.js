"use strict";

import ModuleFactoryInterface from "../modules/ModuleFactoryInterface";
import ComponentFactoryInterface from "../components/ComponentFactoryInterface";

/*
|--------------------------------------------------------------------------
| GET MODULE OBJECT
|--------------------------------------------------------------------------
*/
export const getModule = async (module, request, response, next) => {
    const moduleObject = (await request.factory.get(ModuleFactoryInterface).get(module));
    return moduleObject.run(request, response, next);
};  
/*
|--------------------------------------------------------------------------
| GET COMPONENT OBJECT
|--------------------------------------------------------------------------
*/
export const getComponent = async (component, request, response, next) => {
    const componentObject = (await request.factory.get(ComponentFactoryInterface).get(component));
    return componentObject.run(request, response, next);
};