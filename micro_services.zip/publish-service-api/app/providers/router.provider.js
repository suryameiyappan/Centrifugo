'use strict';

import AppRouter from '../../routes/app.route';
import RouterV1 from '../../routes/api_v1.route';

export default app => {
  app.use('/app', AppRouter);
  app.use('/api/v1', RouterV1);
};