'use strict';

import ModuleFactory from '../modules/ModuleFactory';
import ValidatorFactory from '../validator/ValidatorFactory';
import ComponentFactory from '../components/ComponentFactory';
import ModuleFactoryInterface from '../modules/ModuleFactoryInterface';
import ValidatorFactoryInterface from '../validator/ValidatorFactoryInterface';
import ComponentFactoryInterface from '../components/ComponentFactoryInterface';

const factoryProvider = new Map();
factoryProvider.set(ModuleFactoryInterface, new ModuleFactory());
factoryProvider.set(ComponentFactoryInterface, new ComponentFactory());
factoryProvider.set(ValidatorFactoryInterface, new ValidatorFactory());

export default factoryProvider;
