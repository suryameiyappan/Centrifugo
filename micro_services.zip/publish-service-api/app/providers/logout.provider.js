/*
|--------------------------------------------------------------------------
| BIND APPLICATION SETTINGS USING SET METHOD
|--------------------------------------------------------------------------
*/
const logoutServiceProvider = new Set();

export default logoutServiceProvider;
