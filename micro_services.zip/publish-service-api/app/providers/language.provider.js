'use strict';

import path from 'path';
import i18n from 'i18n';

export default app => {
  i18n.configure({
    locales: ['en', 'hi', 'pt'],
    directory:  path.resolve('resources/locales')
  });
  app.use(i18n.init);
  
  app.use(function (req, res, next) {
    let lang;
    if (req.headers['x-language-code']) {
      lang = req.headers['x-language-code'];
    } else {
      lang = 'en';
    }
    req.setLocale(lang);
    req.trans = i18n.__;
    next();
  });
};
