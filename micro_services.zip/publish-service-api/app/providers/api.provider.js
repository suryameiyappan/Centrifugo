'use strict';

import factoryProvider from './factory.provider';
import logoutServiceProvider from './logout.provider';

export default app => {
  app.use((req, res, next) => {
    req.factory = factoryProvider;
    req.logout = logoutServiceProvider;
    next();
  });
};
