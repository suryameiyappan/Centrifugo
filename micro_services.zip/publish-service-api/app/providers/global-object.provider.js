'use strict';

export const globalObjProvider = (req, res, next) => {
  global.request = req;
  global.response = res;
  global.next = next;
  next();
};
