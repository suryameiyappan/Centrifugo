'use strict';

import fs from 'fs';
import path from 'path';
import morgan from 'morgan';

export default app => {
    if (process.env.NODE_ENV !== 'test') {
		app.use(morgan('short'));
		const accessLogStream = fs.createWriteStream(path.join(__dirname, '../../storage/logs/access.log'), {
			flags: 'a'
		});
		app.use(
			morgan('combined', {
				stream: accessLogStream
			})
		);
	}
};
