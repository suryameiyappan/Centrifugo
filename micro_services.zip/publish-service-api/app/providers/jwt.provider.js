"use strict";

import fs from 'fs';
import jwt from 'jsonwebtoken';

const publicKey = fs.readFileSync('config/key/jwt-pem/jwt-public.pem', 'utf-8');
const privateKey = fs.readFileSync('config/key/jwt-pem/jwt-private.pem', 'utf-8');

class JwtProvider {
  sign(payload, options = {}, secretKey = "") {
    return jwt.sign(payload, (secretKey || privateKey), options);
  }

  verify(token, options = {}) {
    try {
      return jwt.verify(token, publicKey, options);
    } catch (error) {
      return false;
    }
  }

  decode(token) {
    return jwt.decode(token, { complete: true });
  }
}

export default JwtProvider;
