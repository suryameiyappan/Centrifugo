"use strict";

const CENTRIFUGO = "Centrifugo";


export { CENTRIFUGO };
