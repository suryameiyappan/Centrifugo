const AUTH_SERVICE = "AuthService";
const PRODUCT_ROUTES = "ProductRoutes";
const PRODUCT_SERVICE = "ProductService";
const VALIDATOR_CONFIG = "ValidatorConfig";
const SUB_PRODUCT_ROUTES = "SubProductRoutes";

module.exports = {
    AUTH_SERVICE,
    PRODUCT_ROUTES,
    PRODUCT_SERVICE,
    VALIDATOR_CONFIG,
    SUB_PRODUCT_ROUTES
};
