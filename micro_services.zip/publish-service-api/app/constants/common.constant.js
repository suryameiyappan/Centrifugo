const DEV_ENV = "development";
const VERSION = "v1";
const STATUS = true;

module.exports = {
  DEV_ENV,
  VERSION,
  STATUS,
};
