"use strict";

export const runWorker = () => {
    require("./jobs/centrifugo.job");
};
