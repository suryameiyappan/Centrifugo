"use strict";

import Queue from 'bull';
import config from '../../../config/key/app/app.config';

const centrifugoQueue = new Queue('message-publish-queue', {
  redis: {
    host: config.redis.host,
    port: config.redis.port
  }
});

export default centrifugoQueue;
