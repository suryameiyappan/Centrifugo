"use strict";

import centrifugoQueue from '../queues/centrifugo.queue';
import { getComponent } from '../../utils/factory.helper';

centrifugoQueue.process(async (data) => {
    console.log('<<======Worker started======>>');
    try {
        const { component, action } = data.data;
        const { request, response, next } = global;
        request.body.action = action;
        request.body.component = component;
        await getComponent(component, request, response, next);
    
        console.log('<<======Worker ended======>>');
    } catch (error) {
        console.log(`MessageDetails : sendMessage Method : ${error}`);
    }
});
