"use strict";

import { PRODUCT_ROUTES } from "../constants/modules.constant";
import { loadFactory } from "../../config/factory/modules.config";
import ComponentFactoryInterface from "./ComponentFactoryInterface";

class ComponentFactory extends ComponentFactoryInterface {
  /*
  |--------------------------------------------------------------------------
  | CHECK COMPONENT EXISTS
  |--------------------------------------------------------------------------
  */
  async get(component) {
    const componentClass = (await loadFactory(component, PRODUCT_ROUTES));
    if (!componentClass) throw new Error(`Undefined component: ${component}`)
    return (new componentClass());
  }
}

export default ComponentFactory;
