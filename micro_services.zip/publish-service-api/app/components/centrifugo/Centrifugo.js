"use strict";

import Component from "../Component";
import { CENTRIFUGO } from '../../constants/components.constant';
import { loadFactory } from "../../../config/factory/modules.config";
import { SUB_PRODUCT_ROUTES } from "../../constants/modules.constant";

class Centrifugo extends Component {
  /*
  |--------------------------------------------------------------------------
  | CREATE Centrifugo SERVICE CLASS AND METHOD INSTANCE
  |--------------------------------------------------------------------------
  */
  async execute(request, response, next) {
    let serviceClass = (await loadFactory(request.body.action, SUB_PRODUCT_ROUTES));

    if (!serviceClass) {
      throw new Error(
        `${request.body.component} Component : ${request.body.action} componentCode not found`
      );
    }
    return (new serviceClass().process(request, response, next));
  }

  getComponentName() {
    return CENTRIFUGO;
  }
}

module.exports = Centrifugo;