"use strict";

import axios from 'axios';
import config from "../../../../config/key/app/app.config";
import { SUCCESS } from "../../../constants/error.constant";
import { getRoomMembers } from '../../../repositories/room.repositories';
import { MESSAGE_SENDED } from "../../../constants/error-message.constant";

class LeaveRoom {
  /*
  |--------------------------------------------------------------------------
  | Centrifugo Message PROCESS
  |--------------------------------------------------------------------------
  */
  async process(request, response, next) {
    try {
        let reqBody = request.body.data;
        const channels = await getRoomMembers(reqBody.channel_id);
        await axios.post(`${config.centrifugo.api_url}/broadcast`, 
          {
            'channels': channels,
            'data': {
                'type': 'user_leaved',
                'body': {
                  content: reqBody.content,
                  userId: request.user.user_id,
                  createdAt: new Date()
                }
            },
            idempotency_key: `message_${message.id}`,
          }, 
          {
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': config.centrifugo.api_key,
            },
          }
        );
        return { code : SUCCESS, message: MESSAGE_SENDED, data: channels };
    } catch (error) {
        console.log(`LeaveRoom : process Method : ${error}`);
    }
  }
}

module.exports = LeaveRoom;
