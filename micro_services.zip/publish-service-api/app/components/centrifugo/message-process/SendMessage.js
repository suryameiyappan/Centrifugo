"use strict";

import axios from 'axios';
import config from "../../../../config/key/app/app.config";
import { SUCCESS } from "../../../constants/error.constant";
import { getRoomMembers } from '../../../repositories/room.repositories';
import { MESSAGE_SENDED } from "../../../constants/error-message.constant";
import { createMessage, createCdcDetails, createOnlineUserDetails } from '../../../repositories/message.repositories';

class SendMessage {
  /*
  |--------------------------------------------------------------------------
  | Centrifugo Message PROCESS
  |--------------------------------------------------------------------------
  */
  async process(request, response, next) {
    try {
        let reqBody = request.body.data;
        const channels = await getRoomMembers(reqBody.channel_id);
        const message = await createMessage({
          content: reqBody.content,
          room_id: reqBody.channel_id,
          user_id: request.user.user_id
        });
        
        const messagePayload =  {
          'channels': channels,
          'data': {
              'type': 'message_added',
              'body': {
                content: reqBody.content,
                userId: request.user.user_id,
                createdAt: new Date()
              }
          },
          'idempotency_key': `message_${message.id}`,
        };
        await this.broadcast(messagePayload);
        await createCdcDetails({ method: "broadcast", payload: messagePayload, partition: 2 });

        // let onlineUsersDetails = [];
        // channels.forEach(async channel => {
        //   const onlineUsers = await this.getOnlineUsers(channel);
        //   const usersList = Object.values(onlineUsers.presence).map(item => item.user);
        //   onlineUsersDetails.push(usersList);
        // });
        // await createOnlineUserDetails({ online_users: onlineUsersDetails, message_id: message.id, room_id: reqBody.channel_id });

        return { code : SUCCESS, message: MESSAGE_SENDED, data: "" };
    } catch (error) {
        console.log(`SendMessage : process Method : ${error}`);
    }
  }
  /*
  |--------------------------------------------------------------------------
  | Centrifugo Broadcast message
  |--------------------------------------------------------------------------
  */
  async broadcast(payload) {
    try {
      await axios.post(`${config.centrifugo.api_url}/broadcast`, 
        payload, 
        {
          headers: {
              'Content-Type': 'application/json',
              'X-API-Key': config.centrifugo.api_key,
          },
        }
      );
    } catch (error) {
        console.error(`SendMessage :  broadcast Method : ${error}`);
    }
  };
  /*
  |--------------------------------------------------------------------------
  | Centrifugo Get Online users
  |--------------------------------------------------------------------------
  */
  async getOnlineUsers(channelName) {
    try {
        const response = await axios.post(`${config.centrifugo.api_url}/presence`, 
            {
               'method': 'presence',
               'params': { 
                    channel: channelName 
                }
            }, 
            {
              headers: {
                  'Content-Type': 'application/json',
                  'X-API-Key': config.centrifugo.api_key,
              }
            }
        );
        return response.data.result;
    } catch (error) {
      console.error('Error fetching online users:', error);
      throw error;
    }
  };
}

module.exports = SendMessage;
