"use strict";

import { goodBye } from '../utils/http.helper';
import { PRODUCT_SERVICE } from "../constants/modules.constant";
import { VALIDATOR } from "../constants/error-message.constant";
import ModuleFactoryInterface from "../modules/ModuleFactoryInterface";
import ValidatorFactoryInterface from "../validator/ValidatorFactoryInterface";
import { VALIDATION, INTERNAL_SERVER_ERROR } from "../constants/error.constant";
/*
  |--------------------------------------------------------------------------
  | CREATE PRODUCT CLASS AND METHOD INSTANCE
  |--------------------------------------------------------------------------
*/
export const execute = async (request, response, next) => {
  try {
    const validation = (await request.factory.get(ValidatorFactoryInterface).run(request, PRODUCT_SERVICE));
    if (validation) {
      return goodBye(
        response, VALIDATION, VALIDATOR, validation.details.map(error => error.message)
      );
    }
    const serviceObj = (await request.factory.get(ModuleFactoryInterface).get(request.body.module));
    return await serviceObj.run(request, response, next);
  } catch (err) {
    return goodBye(
      response, INTERNAL_SERVER_ERROR, err.message, []
    );
  }
};
