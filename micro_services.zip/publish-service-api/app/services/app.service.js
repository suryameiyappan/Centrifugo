"use strict";

import { goodBye } from '../utils/http.helper';
import cliExecution from '../utils/cli.helper';
import { VERSION } from "../constants/common.constant";
import { API_MSG, SUCCESS_MSG } from "../constants/error-message.constant";

/*
|--------------------------------------------------------------------------
| API VERSION METHOD
|--------------------------------------------------------------------------
*/
export const apiVersion = (request, response, next) => {
  return goodBye(
    response, 200, API_MSG, { version: VERSION }
  );
};

/*
|--------------------------------------------------------------------------
| MONGODB STATUS CHECK
|--------------------------------------------------------------------------
*/
export const mongoStatus = async (request, response, next) => {
  try {
    const output = (await cliExecution('service mongod status'));
    return goodBye(
      response, 200, SUCCESS_MSG, output
    );
  } catch (error) {
    next(new Error(error));
  }
};

/*
|--------------------------------------------------------------------------
| CLI OPERATIONS
|--------------------------------------------------------------------------
*/
export const cliOperations = async (request, response, next) => {
  try {
    const output = (await cliExecution(request.body.command));
    return goodBye(
      response, 200, SUCCESS_MSG, output
    );
  } catch (error) {
    next(new Error(error));
  }
};
