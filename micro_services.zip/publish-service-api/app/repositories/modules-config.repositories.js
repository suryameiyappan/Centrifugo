"use strict";

import model from '../models';

export async function moduleConfig(product, repo) {
  try {
    return await model[repo].findOne({
      where: {
        product: product,
        is_active: true,
      },
    });
  } catch (error) {
    throw new Error(
      `Modules Config Repository modulesConfig Method : ${error}`
    );
  }
}
