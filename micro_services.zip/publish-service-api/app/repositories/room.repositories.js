"use strict";

import model from "../models";
const { RoomMember } = model;

export async function getRoomMembers(roomId) {
  try {
    const members = await RoomMember.findAll({
      where: { room_id: roomId },
      attributes: ['user_id'],
    });
    return members.map(member => `personal:${member.user_id}`);
  } catch (error) {
    throw new Error(`Room Repository getRoomMembers Method : ${error}`);
  }
}