"use strict";

import model from "../models";
const { Message, Room, CDC, RoomUserPresenceStatus } = model;

export async function createMessage(messageData) {
  try {
    const mesage = await Message.create(messageData);
    await Room.update({ last_message_id: mesage.id }, {
      where: {
        id: messageData.room_id
      },
    });
    return mesage;
  } catch (error) {
    throw new Error(`Message Repository createMessage Method : ${error}`);
  }
}

export async function createOnlineUserDetails(messageData) {
  try {
    return await RoomUserPresenceStatus.create(messageData);
  } catch (error) {
    throw new Error(`Message Repository createOnlineUserDetails Method : ${error}`);
  }
}

export async function createCdcDetails(payload) {
  try {
    return await CDC.create(payload);
  } catch (error) {
    throw new Error(`Message Repository createCdcDetails Method : ${error}`);
  }
}