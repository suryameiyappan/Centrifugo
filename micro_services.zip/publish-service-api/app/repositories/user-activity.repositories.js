"use strict";

import model from "../models";
const { RoomMember } = model;

export async function addUserInChannel(request, authUser) {
  try {
    const existingMembership = await RoomMember.findOne({
        where: { room_id: request.room_id, user_id: authUser },
    });
  
    if (existingMembership) 
        return false;

    return await RoomMember.create({
        room_id: request.room_id,
        user_id: authUser,
        joined_at: new Date()
    });
  } catch (error) {
    throw new Error(`UserActivity Repository addUserInChannel Method : ${error}`);
  }
}

export async function removeUserInChannel(request, authUser) {
  try {
    const deletedCount = await RoomMember.destroy({
      where: {
        room_id: request.room_id,
        user_id: authUser,
      },
    });

    if (deletedCount === 0) 
        return false;
    return true;
  } catch (error) {
    throw new Error(`UserActivity Repository removeUserInChannel Method : ${error}`);
  }
}