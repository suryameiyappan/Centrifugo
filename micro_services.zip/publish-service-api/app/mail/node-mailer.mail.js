"use strict";

import ejs from 'ejs';
import juice from 'juice';
import { Log } from './../../config/library/logger.config';
import transporter from './../../config/library/node-mailer.config';

class NodeMailer {
  async execute(request) {
    try {
      const { mailData, mailTemplate, mailOptions } = request;
      const templatePath = `views/mail-template/${mailTemplate}.ejs`;
      const html = await ejs.renderFile(templatePath, mailData);
      const info = await transporter.sendMail({ ...mailOptions, html: juice(html) });
      Log.error('Success sending email:', info);
    } catch (err) {
      Log.error('Error sending email:', err);
    }
  }
}

module.exports = NodeMailer;
