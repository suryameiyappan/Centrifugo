'use strict';

import { Model } from 'sequelize';

export default (sequelize, DataTypes) => {
  class CDC extends Model {
    static associate(models) {
    }

    toJSON() {
      return { ...this.get(), id: undefined };
    }
  }

  CDC.init({
    id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER,
    },
    method: {
      type: DataTypes.TEXT,
      defaultValue: 'publish',
    },
    payload: {
      type: DataTypes.JSONB,
      allowNull: false,
    },
    partition: {
      type: DataTypes.BIGINT,
      defaultValue: 0,
    }
  }, {
    sequelize,
    tableName: 'cdcs',
    modelName: 'CDC',
  });

  return CDC;
};
