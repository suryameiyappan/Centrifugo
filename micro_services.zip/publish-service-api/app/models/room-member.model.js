'use strict';

import { Model } from 'sequelize';

export default (sequelize, DataTypes) => {
  class RoomMember extends Model {
    static associate(models) {
      RoomMember.belongsTo(models.Room, { foreignKey: 'room_id' });
      RoomMember.belongsTo(models.User, { foreignKey: 'user_id' });
    }

    toJSON() {
      return { ...this.get(), id: undefined };
    }
  }

  RoomMember.init({
    id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER,
    },
    room_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'Rooms',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    user_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'Users',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    joinedAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    }
  }, {
    sequelize,
    tableName: 'room_members',
    modelName: 'RoomMember',
    indexes: [
      {
        unique: true,
        fields: ['room_id', 'user_id'],
      },
    ],
  });

  return RoomMember;
};
