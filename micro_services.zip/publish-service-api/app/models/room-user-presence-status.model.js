"use strict";

import { Model } from "sequelize";

export default (sequelize, DataTypes) => {
  class RoomUserPresenceStatus extends Model {
    static associate(models) {
      UserPresenceStatus.belongsTo(models.Message, {
        foreignKey: "message_id",
        as: "message",
      });
      UserPresenceStatus.belongsTo(models.Room, {
        foreignKey: "room_id",
        as: "room",
      });
    }

    toJSON() {
      return { ...this.get() };
    }
  }

  RoomUserPresenceStatus.init(
    {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      online_users: {
        type: DataTypes.JSONB,
        allowNull: true
      },
      message_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "messages",
          key: "id",
        },
      },
      room_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "rooms",
          key: "id",
        },
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
    },
    {
      sequelize,
      tableName: "room_user_presence_status",
      modelName: "RoomUserPresenceStatus",
    }
  );

  return RoomUserPresenceStatus;
};