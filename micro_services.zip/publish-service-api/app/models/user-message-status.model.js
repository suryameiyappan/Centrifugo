"use strict";

import { Model } from "sequelize";

export default (sequelize, DataTypes) => {
  class UserMessageStatus extends Model {
    static associate(models) {
    }

    toJSON() {
      return { ...this.get() };
    }
  }

  UserMessageStatus.init(
    {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      handle: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      is_verified: {
        type: DataTypes.TINYINT,
        allowNull: false,
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
    },
    {
      sequelize,
      tableName: "user_message_status",
      modelName: "UserMessageStatus",
    }
  );

  return UserMessageStatus;
};