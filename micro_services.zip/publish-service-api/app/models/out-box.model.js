'use strict';

import { Model } from 'sequelize';

export default (sequelize, DataTypes) => {
  class Outbox extends Model {
    static associate(models) {
    }

    toJSON() {
      return { ...this.get(), id: undefined };
    }
  }

  Outbox.init({
    id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER,
    },
    method: {
      type: DataTypes.TEXT,
      defaultValue: 'publish',
    },
    payload: {
      type: DataTypes.JSONB,
      allowNull: false,
    },
    partition: {
      type: DataTypes.BIGINT,
      defaultValue: 0,
    }
  }, {
    sequelize,
    tableName: 'out_boxes',
    modelName: 'Outbox',
  });

  return Outbox;
};
