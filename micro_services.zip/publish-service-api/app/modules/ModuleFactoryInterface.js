"use strict";

class ModuleFactoryInterface {
  /**
   * @param {string} module
   *
   * @return {object}
   */
  async get(module) {
    throw new Error(
      'ModuleFactoryInterface : Subclasses must implement the "get" method'
    );
  }
}

export default ModuleFactoryInterface;
