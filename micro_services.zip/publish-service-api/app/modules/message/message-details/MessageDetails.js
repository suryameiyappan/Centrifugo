"use strict";

import { goodBye } from '../../../utils/http.helper';
import { SUCCESS } from '../../../constants/error.constant';
import { CENTRIFUGO } from '../../../constants/components.constant';
import centrifugoQueue from '../../../worker/queues/centrifugo.queue';
import { MESSAGE_SEND } from '../../../constants/error-message.constant';

class MessageDetails {
  /*
  |------------------------------------------------
  | Function to send message to centrifugo server
  |------------------------------------------------
  */
  async sendMessage(request, response, next) {
    try {
      centrifugoQueue.add({
        component: CENTRIFUGO,
        action: 'MessageProcesser'
      });
      return goodBye(
        response, SUCCESS, MESSAGE_SEND, []
      );
    } catch (error) {
      next(new Error(`MessageDetails : sendMessage Method : ${error}`));
    }
  }
}

module.exports = MessageDetails;
