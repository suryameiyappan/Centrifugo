"use strict";

import Module from "../Module";
import { getModuleObject } from "../../utils/module.helper";

class Message extends Module {
  /*
  |--------------------------------------------------------------------------
  | CREATE Message CLASS AND METHOD INSTANCE
  |--------------------------------------------------------------------------
  */
  async execute(request, response, next) {
    const messageModule = await getModuleObject(request);
    return messageModule[request.body.action](
      request,
      response,
      next
    );
  }
  
  getModuleName() {
    return "Message";
  }
}

module.exports = Message;