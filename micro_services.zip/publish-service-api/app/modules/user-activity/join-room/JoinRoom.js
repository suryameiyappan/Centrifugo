"use strict";

import { goodBye } from '../../../utils/http.helper';
import { CENTRIFUGO } from '../../../constants/components.constant';
import centrifugoQueue from '../../../worker/queues/centrifugo.queue';
import { SUCCESS, FAILED_RETRIVE_CODE } from '../../../constants/error.constant';
import { addUserInChannel } from '../../../repositories/user-activity.repositories';
import { JOIN_CHANNEL, USER_JOIN_CHANNEL_EXISTS } from '../../../constants/error-message.constant';

class JoinRoom {
  /*
  |---------------------------------
  | Function to join user in channel
  |---------------------------------
  */
  async joinRoom(request, response, next) {
    try {
      let reqBody = request.body.data;
      const data = await addUserInChannel(reqBody, request.user.user_id);
      if (! data) {
          return goodBye(
            response, FAILED_RETRIVE_CODE, USER_JOIN_CHANNEL_EXISTS, []
          );
      }
      centrifugoQueue.add({
        component: CENTRIFUGO,
        action: 'JoinRoomProcesser'
      });
      return goodBye(
        response, SUCCESS, JOIN_CHANNEL, data
      );
    } catch (error) {
      next(new Error(`JoinRoom : joinRoom Method : ${error}`));
    }
  }
}

module.exports = JoinRoom;
