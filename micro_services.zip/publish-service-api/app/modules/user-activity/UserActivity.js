"use strict";

import Module from "../Module";
import { getModuleObject } from "../../utils/module.helper";

class UserActivity extends Module {
  /*
  |--------------------------------------------------------------------------
  | CREATE UserActivity CLASS AND METHOD INSTANCE
  |--------------------------------------------------------------------------
  */
  async execute(request, response, next) {
    const userActivityModule = await getModuleObject(request);
    return userActivityModule[request.body.action](
      request,
      response,
      next
    );
  }
  
  getModuleName() {
    return "UserActivity";
  }
}

module.exports = UserActivity;
