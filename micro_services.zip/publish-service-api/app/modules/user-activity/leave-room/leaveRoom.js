"use strict";

import { goodBye } from '../../../utils/http.helper';
import { CENTRIFUGO } from '../../../constants/components.constant';
import centrifugoQueue from '../../../worker/queues/centrifugo.queue';
import { SUCCESS, FAILED_RETRIVE_CODE } from '../../../constants/error.constant';
import { removeUserInChannel } from '../../../repositories/user-activity.repositories';
import { LEAVE_CHANNEL, USER_LEAVE_CHANNEL_EXISTS } from '../../../constants/error-message.constant';

class LeaveRoom {
  /*
  |---------------------------------
  | Function to join user in channel
  |---------------------------------
  */
  async leaveRoom(request, response, next) {
    try {
      let reqBody = request.body.data;
      const data = await removeUserInChannel(reqBody, request.user.user_id);
      if (! data) {
          return goodBye(
            response, FAILED_RETRIVE_CODE, USER_LEAVE_CHANNEL_EXISTS, []
          );
      }
      centrifugoQueue.add({
        component: CENTRIFUGO,
        action: 'leaveRoomProcesser'
      });
      return goodBye(
        response, SUCCESS, LEAVE_CHANNEL, data
      );
    } catch (error) {
      next(new Error(`LeaveRoom : leaveRoom Method : ${error}`));
    }
  }
}

module.exports = LeaveRoom;

