"use strict";

import ModuleFactoryInterface from "./ModuleFactoryInterface";
import { PRODUCT_ROUTES } from "../constants/modules.constant";
import { loadFactory } from "../../config/factory/modules.config";

class ModuleFactory extends ModuleFactoryInterface {
  /*
  |--------------------------------------------------------------------------
  | CHECK MODULE EXISTS
  |--------------------------------------------------------------------------
  */
  async get(module) {
    const moduleClass = (await loadFactory(module, PRODUCT_ROUTES));
    if (!moduleClass) throw new Error(`Undefined module: ${module}`);
    return (new moduleClass());
  }
}

export default ModuleFactory;
