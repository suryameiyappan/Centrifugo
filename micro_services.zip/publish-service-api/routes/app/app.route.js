'use strict';

import { Router } from 'express';
import { authMiddleware } from './../../app/middleware/auth.middleware';
import { apiVersion, mongoStatus, cliOperations } from './../../app/services/app.service';

const router = Router();

router.get("/version", apiVersion);
router.get("/mongodb/status", mongoStatus);
router.post("/cli-operations", authMiddleware(), cliOperations);

export default router;

