'use strict';

import express from 'express';
import appRouter from './app/app.route';

const app = express();

app.get('/up', function (req, res) {
	res.send('User details api running');
});
app.use('/application', appRouter);

export default app;