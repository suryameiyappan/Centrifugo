'use strict';

import express from 'express';
import MessageRouter from './v1/message.route';
import { authMiddleware } from '../app/middleware/auth.middleware';

const app = express();

app.use("/message", authMiddleware(), MessageRouter);

export default app;