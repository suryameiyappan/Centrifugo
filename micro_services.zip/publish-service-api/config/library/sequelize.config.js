"use strict";

import dotenv from 'dotenv';
import appConfig  from '../key/app/app.config';

dotenv.config();

module.exports = {
  development: {
    username: appConfig.pgsql.username,
    password: appConfig.pgsql.password,
    database: appConfig.pgsql.database,
    host: appConfig.pgsql.host,
    dialect: appConfig.pgsql.dialect
  },
  test: {
    username: appConfig.pgsql.username,
    password: appConfig.pgsql.password,
    database: appConfig.pgsql.database,
    host: appConfig.pgsql.host,
    dialect: appConfig.pgsql.dialect
  },
  production: {
    username: appConfig.pgsql.username,
    password: appConfig.pgsql.password,
    database: appConfig.pgsql.database,
    host: appConfig.pgsql.host,
    dialect: appConfig.pgsql.dialect
  }
};
