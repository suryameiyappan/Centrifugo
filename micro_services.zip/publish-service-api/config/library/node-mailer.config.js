"use strict";

import nodemailer from 'nodemailer';
import config from '../key/app/app.config';

const transporter = nodemailer.createTransport({
  host: config.node_mailer.host,
  port: config.node_mailer.port,
  secure: config.node_mailer.secure,
  auth: {
    user: config.node_mailer.auth.user,
    pass: config.node_mailer.auth.pass
  }
});

export default transporter;
