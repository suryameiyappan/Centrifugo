"use strict";

import session from "express-session";
import RedisStore from "connect-redis";
import { redisClient } from "../db/redis.config";


const RedisStoreInstance = RedisStore(session);

export const sessionConfig = () => {
  return {
    name: "PSA",
    store: new RedisStoreInstance({
      client: redisClient,
      db: parseInt(process.env.REDIS_DB),
      ttl: 3600,
    }),
    cookie: {
      domain: process.env.SESSION_DOMAIN,
      maxAge: 3600000,
      httpOnly: true,
    },
    secret: process.env.SESSION_SECRET,
    resave: true,
    saveUninitialized: true,
  };
};
