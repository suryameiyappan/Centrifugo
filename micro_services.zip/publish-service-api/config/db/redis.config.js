"use strict";

import { createClient } from 'redis';
import config from '../key/app/app.config';

const redisConnection = createClient({
    host: config.redis.host,
    port: config.redis.port,
    db: config.redis.db
});

async function connectRedis() {
    try {
        await redisConnection.connect();
        console.log('Redis client connected successfully');
    } catch (err) {
        console.log(`Redis connection failed: ${err}`);
    }
}

connectRedis();

export default redisConnection;
