"use strict";

import db from '../../app/models';

/**
 * Connect to Pgsql db
 * @returns {object} Pgsql connection
 * @public
 */
export const connectPgsql = () => {
  db.sequelize.sync({ force: false }).then(() => {
    console.log("Pgsql db has been re sync")
  })
  .catch((err) => {
    console.log("Failed to connect Pgsql: " + err.message);
  });
};
