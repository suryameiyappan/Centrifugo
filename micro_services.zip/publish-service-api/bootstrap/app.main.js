'use strict';

import path from 'path';
import cors from 'cors';
import helmet from 'helmet';
import logger from 'morgan'; 
import express from 'express';
import bodyParser from 'body-parser';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import multipart from 'connect-multiparty';
import config from '../config/key/app/app.config';
import apiProvider from '../app/providers/api.provider';
import logProvider from '../app/providers/logger.provider';
import routerProvider from '../app/providers/router.provider';
import languageProvider from '../app/providers/language.provider';
import { globalObjProvider } from '../app/providers/global-object.provider';

export default app => {
	/*
	|--------------------------------------------------------------------------
	| CONFIGURE EXPRESS MIDDLEWARES
	|--------------------------------------------------------------------------
	*/
	app.use(
		bodyParser.urlencoded({
			extended: false
		})
	);
	app.use(
		multipart({
			uploadDir: config.tmp
		})
	);
	app.use(cors());
	app.use(helmet());
	app.use(logger("dev"));
	app.use(compression());
	app.use(express.json());
	app.use(cookieParser());
	app.use(bodyParser.json());
	app.use(globalObjProvider);
	app.use(express.static(path.join(__dirname, "public")));
	/*
	|--------------------------------------------------------------------------
	| CONFIGURE APP PROVIDERS
	|--------------------------------------------------------------------------
	*/
	logProvider(app);
	apiProvider(app);
	languageProvider(app);
	routerProvider(app);
	/*
	|--------------------------------------------------------------------------
	| CONFIGURE RESPONSE HEADERS
	|--------------------------------------------------------------------------
	*/
	app.use((req, res, next) => {
		res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');
		res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, PUT, OPTIONS');
		res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept,X-REQUEST-TYPE, X-LANGUAGE-CODE, Authorization');
		res.set('Access-Control-Allow-Credentials', 'true');
		next();
	});
};
