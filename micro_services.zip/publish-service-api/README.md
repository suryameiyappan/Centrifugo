

mail Template: 
https://github.com/ActiveCampaign/postmark-templates/tree/main/templates-inlined

Package install command:  npm install
migration command:  npx sequelize-cli db:migrate
seeder command:     npx sequelize-cli db:seed:all
application run command:  pm2 start dev.json

