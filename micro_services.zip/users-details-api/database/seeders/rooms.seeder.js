"use strict";

/** @type {import('sequelize-cli').Seeder} */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert('rooms', [
      {
        name: 'DEV',
        version: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        bumpedAt: new Date(),
        last_message_id: null,
      },
      {
        name: 'QA',
        version: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        bumpedAt: new Date(),
        last_message_id: null,
      },
      {
        name: 'HR',
        version: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        bumpedAt: new Date(),
        last_message_id: null,
      },
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('rooms', null, {});
  },
};