'use strict';

import bcrypt from "bcrypt";
import { generateToken} from "./../../app/utils/common.helper";
  
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('users', [
      { 
        username: 'joker',
        password: bcrypt.hashSync('surya@123', 10),
        email: 'surya@gmail.com', 
        phone_number: '9943098715',
        verify_token: generateToken(53),
        provider: "BASIC_LOGIN",
        is_verified: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      }
    ], {});
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('users', null, {});
  }
};