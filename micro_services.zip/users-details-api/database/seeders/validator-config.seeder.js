'use strict';

/**
 *  @type {import('sequelize-cli').Migration} 
 * */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('validator_config', [
      { product: 'AuthService', 
        product_class: '../../app/validator/service/auth.validation', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'ProductService', 
        product_class: '../../app/services/validators/product.validation', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'JwtAuth', 
        product_class: '../../app/validator/module/auth/jwt/jwt.validation', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ], {});
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('validator_config', null, {});
  }
};