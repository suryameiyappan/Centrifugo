'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('sub_product_routes', [
      { 
        product: 'JwtAuth', 
        product_class: '../../app/modules/auth/jwt/JwtAuth', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'RoomDetails', 
        product_class: '../../app/modules/rooms/room-details/RoomDetails', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'ConToken', 
        product_class: '../../app/modules/centrifugo-token/connection/connectionToken', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'SubToken', 
        product_class: '../../app/modules/centrifugo-token/subscription/subscriptionToken', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'LeaveRoom', 
        product_class: '../../app/modules/user-activity/leave-room/leaveRoom', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'JoinRoom', 
        product_class: '../../app/modules/user-activity/join-room/JoinRoom', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'MessageDetails', 
        product_class: '../../app/modules/message/message-details/MessageDetails', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'MessageProcesser', 
        product_class: '../../app/components/centrifugo/message-process/SendMessage', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'leaveRoomProcesser', 
        product_class: '../../app/components/centrifugo/leave-room/leaveRoom', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'JoinRoomProcesser', 
        product_class: '../../app/components/centrifugo/join-room/JoinRoom', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'UserRooms', 
        product_class: '../../app/modules/rooms/user-rooms/UserRooms', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'ChatHistory', 
        product_class: '../../app/modules/chats/chat-history/ChatHistory', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
    ], {});
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('sub_product_routes', null, {});
  }
};