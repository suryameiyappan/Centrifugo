'use strict';

/**
 *  @type {import('sequelize-cli').Migration} 
 * */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('user_message_status', [
      { 
        handle: 'received', 
        name: 'Received', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        handle: 'pendiing', 
        name: 'Pending', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ], {});
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('user_message_status', null, {});
  }
};