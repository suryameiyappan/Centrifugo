'use strict';

/** 
 * 
 * @type {import('sequelize-cli').Migration} 
 */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('product_routes', [
      { 
        product: 'Auth', 
        product_class: '../../app/modules/auth/Auth', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'Room', 
        product_class: '../../app/modules/rooms/Rooms', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'CentrifugoTokenConfig', 
        product_class: '../../app/modules/centrifugo-token/CentrifugoToken', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'UserActivity', 
        product_class: '../../app/modules/user-activity/UserActivity', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'Message', 
        product_class: '../../app/modules/message/Message', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'Centrifugo', 
        product_class: '../../app/components/centrifugo/Centrifugo', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
      { 
        product: 'Chats', 
        product_class: '../../app/modules/chats/Chats', 
        is_active: true, 
        createdAt: new Date(),
        updatedAt: new Date()
      },
    ], {});
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('product_routes', null, {});
  }
};