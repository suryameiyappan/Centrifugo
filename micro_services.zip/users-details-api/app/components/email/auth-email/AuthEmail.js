"use strict";

import emailQueue from '../../../worker/queues/email.queue';
import { SUCCESS } from "../../../constants/error.constant";
import { MAIL_SENDED } from "../../../constants/error-message.constant";

class AuthEmail {
  /*
  |--------------------------------------------------------------------------
  | AUTH USER MAIL PROCESS
  |--------------------------------------------------------------------------
  */
  process(request, response, next) {
    const { template, mailData, mailOptions } = request.body.data;
    emailQueue.add({
      mailTemplate: template,
      mailData: mailData,
      mailOptions: {
        from: `"${process.env.NODE_MAILER_SENDER_NAME}" <${process.env.NODE_MAILER_USERNAME}>`,
        ...mailOptions
      }
    });
    return { code : SUCCESS, message: MAIL_SENDED };
  }

}

module.exports = AuthEmail;
