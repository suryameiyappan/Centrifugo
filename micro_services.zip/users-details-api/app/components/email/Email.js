"use strict";

import Component from "../Component";
import { loadFactory } from "../../../config/factory/modules.config";
import { SUB_PRODUCT_ROUTES } from "../../constants/modules.constant";

class Email extends Component {
  /*
  |--------------------------------------------------------------------------
  | CREATE EMAIL SERVICE CLASS AND METHOD INSTANCE
  |--------------------------------------------------------------------------
  */
  async execute(request, response, next) {
    let serviceClass = (await loadFactory(request.body.action, SUB_PRODUCT_ROUTES));
    if (!serviceClass) {
      throw new Error(
        `${request.body.component} Component : ${request.body.action} method not found`
      );
    }
    return (new serviceClass().process(request, response, next));
  }

  getComponentName() {
    return "EMAIL";
  }
}

module.exports = Email;
