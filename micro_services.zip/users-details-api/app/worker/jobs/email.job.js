"use strict";

import emailQueue from '../queues/email.queue';

emailQueue.process(async (data) => {
    console.log('<<======Worker started======>>');
    console.log('<<======Worker ended======>>');
});
