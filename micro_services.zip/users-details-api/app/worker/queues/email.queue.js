"use strict";

import Queue from 'bull';
import config from '../../../config/key/app/app.config';

const emailQueue = new Queue('email-queue', {
  redis: {
    host: config.redis.host,
    port: config.redis.port
  }
});

export default emailQueue;
