"use strict";

export const runWorker = () => {
    require("./jobs/email.job");
};
