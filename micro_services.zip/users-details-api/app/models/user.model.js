import { Model } from 'sequelize';

export default (sequelize, DataTypes) => {
  class Users extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate() {
      // Define associations here if needed
    }

    toJSON() {
      return { ...this.get(), password: undefined };
    }
  }

  Users.init({
    id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER,
    },
    username: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    email: {
      type: DataTypes.STRING,
    },
    phone_number: {
      type: DataTypes.STRING,
    },
    provider: {
      type: DataTypes.STRING,
    },
    profile_url: {
      type: DataTypes.STRING,
    },
    verify_token: {
      type: DataTypes.STRING,
    },
    is_verified: {
      type: DataTypes.TINYINT,
    },
  }, {
    sequelize,
    tableName: 'users',
    modelName: 'Users',
  });

  return Users;
};
