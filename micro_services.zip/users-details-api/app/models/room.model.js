'use strict';

import { Model } from 'sequelize';

export default (sequelize, DataTypes) => {
  class Room extends Model {
    static associate(models) {
      Room.hasMany(models.Message, { foreignKey: 'room_id', as: 'messages' });
      Room.hasMany(models.RoomMember, { foreignKey: 'room_id', as: 'roomMembers' });
      Room.belongsTo(models.Message, { foreignKey: 'last_message_id', as: 'lastMessage' });
    }

    toJSON() {
      return { ...this.get() };
    }

    incrementVersion() {
      this.version += 1;
      this.save();
      return this.version;
    }
  }

  Room.init({
    id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    version: {
      type: DataTypes.BIGINT,
      defaultValue: 0,
    },
    last_message_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'messages',
        key: 'id',
      },
      onDelete: 'SET NULL',
      allowNull: true,
    },
    bumpedAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
  }, {
    sequelize,
    tableName: 'rooms',
    modelName: 'Room',
  });

  return Room;
};
