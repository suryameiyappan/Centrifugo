"use strict";

import bcrypt from "bcrypt";
import model from "../models";
import { faker } from "@faker-js/faker";
const { Users, Room, RoomMember } = model;
import { Log } from '../../config/library/logger.config';

export async function createUsers(n) {
    let users = [];
    let total = 0;
    let emails = new Set();

    for (let i = 0; i < n; i++) {
        const firstName = faker.person.firstName();
        const lastName = faker.person.lastName();
        const username = `${firstName.toLowerCase()}${lastName.toLowerCase()}${Math.floor(Math.random() * 10000)}`;

        let email;
        let phone_number = "9943098715";
        let provider = "BASIC_LOGIN";
        let profile_url = "NULL";
        let verify_token = "KQt1Sph9PcsK42t0y8RV28zuKlwd7urWVXvTghm74HwtapPmqak88";
        let is_verified = true;
        do {
            email = faker.internet.email();
        } while (emails.has(email));
        emails.add(email); 

        const password = faker.internet.password();
        // const password = bcrypt.hashSync(genPassword, 10);

        Log.error("gmail "+email + " password " + password);

        const user = {
            username,
            email,
            password,
            phone_number,
            provider,
            profile_url,
            verify_token,
            is_verified,
            createdAt: new Date(),
            updatedAt: new Date(),
        };
        
        users.push(user);

        if (users.length >= 100) {
            await Users.bulkCreate(users);
            total += users.length;
            users = [];
            console.log(`Total users created: ${total}`);
        }
    }

    if (users.length > 0) {
        await User.bulkCreate(users);
        total += users.length;
        console.log(`Total users created: ${total}`);
    }
}

export async function createRoom(name) {
    const room = await Room.create({ name });
    return room;
}

export async function fillRoom(roomId, limit) {
    let members = [];
    let total = 0;

    const room = await Room.findByPk(roomId);
    if (!room) {
        console.log(`Room with ID ${roomId} not found.`);
        return;
    }

    const users = await Users.findAll({ limit });
    for (let user of users) {
        members.push({ room_id: room.id, user_id: user.id });

        if (members.length >= 100) {
            await RoomMember.bulkCreate(members, { ignoreDuplicates: true });
            total += members.length;
            members = [];
            console.log(`Total members created: ${total}`);
        }
    }

    if (members.length > 0) {
        await RoomMember.bulkCreate(members, { ignoreDuplicates: true });
        total += members.length;
        console.log(`Total members created: ${total}`);
    }
}

export async function setupDev() {
    await createUsers(100000);
    
    const r1 = await createRoom('Centrifugo');
    await fillRoom(r1.id, 100000);
    
    const r2 = await createRoom('Movies');
    await fillRoom(r2.id, 500);
    
    const r3 = await createRoom('Programming');
    await fillRoom(r3.id, 50);
    
    const r4 = await createRoom('Football');
    await fillRoom(r4.id, 10);
}
