"use strict";

import model from "../models";
const { Message } = model;

export async function fetchChatHistory(request) {
  try {
    const chatsHistory = await Message.findAll({
        where: {
            room_id: request.body.data.room_id
        },
        order: [['createdAt', 'ASC']]
    });
    
    return chatsHistory.map((message) => {
        const isOutgoing = message.user_id === request.user.user_id;
        return {
            ...message.toJSON(),
            type: isOutgoing ? 'outgoing' : 'incoming',
        };
    });
  } catch (error) {
    throw new Error(`ChatHistory Repository fetchChatHistory Method : ${error}`);
  }
}