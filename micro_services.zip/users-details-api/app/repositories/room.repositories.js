"use strict";

import model from "../models";
const { Room, RoomMember, Message } = model;

export async function createRoom(userData) {
  try {
    return await Room.create(userData);
  } catch (error) {
    throw new Error(`Room Repository createRoom Method : ${error}`);
  }
}

export async function listAllRooms() {
    try {
        return await Room.findAll();
    } catch (error) {
      throw new Error(`Room Repository listAllRooms Method : ${error}`);
    }
}

export async function listUserRoomDetails(request) {
    try {
      let roomData = [];
      const roomMembers = await RoomMember.findAll({
        where: {
          user_id: request.user.user_id
        },
      });

      for (const room of roomMembers) {
        const roomInfo = await Room.findOne({
          where: {
            id: room.room_id,
          },
          order: [['updatedAt', 'DESC']],
        });
        
        if (roomInfo) {
          const lastMessage = await Message.findOne({
            where: {
              room_id: room.room_id
            },
            order: [['updatedAt', 'DESC']],
            limit: 1
          });

          roomData.push({
            room: roomInfo,
            lastMessage: lastMessage || null
          });
        }
      }
      return roomData;

    } catch (error) {
      throw new Error(`Room Repository listUserRoomDetails Method : ${error}`);
    }
}

export async function getRoomMembers(roomId) {
  try {
    const members = await RoomMember.findAll({
      where: { room_id: roomId },
      attributes: ['user_id'],
    });
    return members.map(member => `personal:${member.user_id}`);
  } catch (error) {
    throw new Error(`Room Repository getRoomMembers Method : ${error}`);
  }
}