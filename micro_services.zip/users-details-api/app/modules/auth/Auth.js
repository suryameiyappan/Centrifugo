"use strict";

import Module from "../Module";
import { getModuleObject } from "../../utils/module.helper";

class Auth extends Module {
  /*
  |--------------------------------------------------------------------------
  | CREATE Auth CLASS AND METHOD INSTANCE
  |--------------------------------------------------------------------------
  */
  async execute(request, response, next) {
    const authModule = await getModuleObject(request);
    return authModule[request.body.action](
      request,
      response,
      next
    );
  }
  
  getModuleName() {
    return "Auth";
  }
}

module.exports = Auth;
