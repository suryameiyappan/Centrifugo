"use strict";

import bcrypt from 'bcrypt';
import { goodBye } from '../../../utils/http.helper';
import JwtProvider from '../../../providers/jwt.provider';
import { generateToken } from '../../../utils/common.helper';
import { jwtOptions } from '../../../../config/library/jwt.config';
import {
  SUCCESS_MSG, DATA_INSERT, INVALID_CREDENTIALS, NO_RECORD_FOUND, DATA_UPDATED,
  LOG_OUT_SUCCESS, LOG_OUT_FAILURE, USERNAME_EXIST, USER_ALREADY_VERIFIED, FORGOT_PASS_SUCC_MSG
} from '../../../constants/error-message.constant';
import { SUCCESS, FAILED_RETRIVE_CODE, INTERNAL_SERVER_ERROR } from '../../../constants/error.constant';
import { getUserName, forgotPassword, updateVerifyStatus, registerUser } from '../../../repositories/auth.repositories';


class JwtAuth {
  jwtAuthProvider = JwtProvider;
  /*
  |----------------------------
  | Constructor
  |----------------------------
  */
  constructor(jwtProvider = new JwtProvider()) {
    this.jwtAuthProvider = jwtProvider;
  }
  /*
  |----------------------------
  | Function to register user
  |----------------------------
  */
  async register(request, response, next) {
    let reqBody = request.body.data;
    const userInfo = {
      username: reqBody.username,
      password: bcrypt.hashSync(reqBody.password, 10),
      email: reqBody.email,
      phone_number: reqBody.phone_number,
      provider: 'BASIC_LOGIN',
      is_verified: 0,
      verify_token: generateToken(53)
    };

    try {
      const data = await registerUser(userInfo);
      if (data === 1) {
        return goodBye(
          response, FAILED_RETRIVE_CODE, USERNAME_EXIST, []
        );
      }
      return goodBye(
        response, SUCCESS, DATA_INSERT, data
      );
    } catch (error) {
      next(new Error(`Authentication : register Method : ${error}`));
    }
  }

  /*
  |----------------------------
  | Function to Verify User
  |----------------------------
  */
  async verification(request, response, next) {
    let reqBody = request.body.data;
    try {
      const data = await updateVerifyStatus(reqBody.verify_token);
      if (data === null) {
        return goodBye(
          response, FAILED_RETRIVE_CODE, USER_ALREADY_VERIFIED, []
        );
      }
      return goodBye(
        response, SUCCESS, DATA_UPDATED, []
      );
    } catch (error) {
      next(new Error(`Authentication : verification Method : ${error}`));
    }
  }

  /*
  |----------------------------
  | Function to login user
  |----------------------------
  */
  async login(request, response, next) {
    let reqBody = request.body.data;
    try {
      const data = await getUserName(reqBody);
      if (data === null) {
        return goodBye(
          response, FAILED_RETRIVE_CODE, INVALID_CREDENTIALS, []
        );
      }
      // const checkPassword = await bcrypt.compare(reqBody.password, data.password);
      const checkPassword = reqBody.password === data.password;
      if (!checkPassword) {
        return goodBye(
          response, FAILED_RETRIVE_CODE, INVALID_CREDENTIALS, []
        );
      }
      const token = this.jwtAuthProvider.sign({ user_id: data.id }, jwtOptions);
      return goodBye(
        response, SUCCESS, SUCCESS_MSG, { token: token, user: data }
      );
    } catch (error) {
      next(new Error(`Authentication : login Method : ${error}`));
    }
  }

  /*
  |----------------------------
  | Function to Forgot Password
  |----------------------------
  */
  async forgotPassword(request, response, next) {
    let reqBody = request.body.data, newPassword = generateToken(8);
    const userInfo = {
      email: reqBody.email,
      password: bcrypt.hashSync(newPassword, 10)
    };

    try {
      const data = await forgotPassword(userInfo);
      if (data === null) {
        return goodBye(
          response, FAILED_RETRIVE_CODE, NO_RECORD_FOUND, []
        );
      }
      return goodBye(
        response, SUCCESS, FORGOT_PASS_SUCC_MSG, []
      );
    } catch (error) {
      next(new Error(`Authentication : forgotPassword Method : ${error}`));
    }
  }

  /*
  |----------------------------
  | Function to logout user
  |----------------------------
  */
  logout(request, response, next) {
    const token = request.header('Authorization') ? request.header('Authorization').split(' ')[1] : '';
    if (token && !request.logout.has(token)) {
      request.logout.add(token);
      return goodBye(
        response, SUCCESS, LOG_OUT_SUCCESS, []
      );
    }
    return goodBye(
      response, INTERNAL_SERVER_ERROR, LOG_OUT_FAILURE, []
    );
  }
}

module.exports = JwtAuth;
