"use strict";

import { goodBye } from '../../../utils/http.helper';
import { SUCCESS } from '../../../constants/error.constant';
import { ROOM_CREATED } from '../../../constants/error-message.constant';
import { createRoom, listAllRooms, listRoomDetails } from '../../../repositories/room.repositories';


class RoomDetails {
  /*
  |----------------------------
  | Function to create channel
  |----------------------------
  */
  async createRoom(request, response, next) {
    try {
      let reqBody = request.body.data;
      const roomInfo = {
        name: reqBody.channel_name
      };
      const data = await createRoom(roomInfo);
      return goodBye(
        response, SUCCESS, ROOM_CREATED, data
      );
    } catch (error) {
      next(new Error(`Authentication : register Method : ${error}`));
    }
  }
  /*
  |----------------------------
  | Function to retrive rooms list
  |----------------------------
  */
  async listAllRooms(request, response, next) {
    try {
      const data = await listAllRooms();
      return goodBye(
        response, SUCCESS, ROOM_CREATED, data
      );
    } catch (error) {
      next(new Error(`Authentication : register Method : ${error}`));
    }
  }
}

module.exports = RoomDetails;
