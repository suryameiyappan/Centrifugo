"use strict";

import Module from "../Module";
import { getModuleObject } from "../../utils/module.helper";

class Rooms extends Module {
  /*
  |--------------------------------------------------------------------------
  | CREATE Rooms CLASS AND METHOD INSTANCE
  |--------------------------------------------------------------------------
  */
  async execute(request, response, next) {
    const roomsModule = await getModuleObject(request);
    return roomsModule[request.body.action](
      request,
      response,
      next
    );
  }
  
  getModuleName() {
    return "Rooms";
  }
}

module.exports = Rooms;
