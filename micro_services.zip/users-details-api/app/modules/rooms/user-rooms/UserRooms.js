"use strict";

import { goodBye } from '../../../utils/http.helper';
import { SUCCESS } from '../../../constants/error.constant';
import { ROOM_CREATED } from '../../../constants/error-message.constant';
import { listUserRoomDetails } from '../../../repositories/room.repositories';


class UserRooms {
   /*
  |------------------------------------------------
  | Function to retrive user based rooms details
  |------------------------------------------------
  */
  async listUserRoomDetails(request, response, next) {
    try {
      const data = await listUserRoomDetails(request);
      return goodBye(
        response, SUCCESS, ROOM_CREATED, data
      );
    } catch (error) {
      next(new Error(`UserRooms : listUserRoomDetails Method : ${error}`));
    }
  }
}

module.exports = UserRooms;