"use strict";

import { goodBye } from '../../../utils/http.helper';
import JwtProvider from '../../../providers/jwt.provider';
import config from '../../../../config/key/app/app.config';
import { SUCCESS } from '../../../constants/error.constant';
import { TOKEN_CREATED } from '../../../constants/error-message.constant';


class subscriptionToken {
  jwtAuthProvider = JwtProvider;
  /*
  |----------------------------
  | Constructor
  |----------------------------
  */
  constructor(jwtProvider = new JwtProvider()) {
    this.jwtAuthProvider = jwtProvider;
  }
  /*
  |----------------------------
  | Function to subscription token
  |----------------------------
  */
  async subscriptionToken(request, response, next) {
    try {
      let reqBody = request.body.data;
      const tokenClaims = {
        channel: reqBody.channel,
        sub: String(request.user.user_id),
        exp: Math.floor(Date.now() / 1000) + 300,
        info: {
          presence: true
        }
      };
      const token = this.jwtAuthProvider.sign(tokenClaims, {}, config.centrifugo.secret_key);
      return goodBye(
        response, SUCCESS, TOKEN_CREATED, token
      );
    } catch (error) {
      next(new Error(`subscriptionToken : subscriptionToken Method : ${error}`));
    }
  }
}

module.exports = subscriptionToken;
