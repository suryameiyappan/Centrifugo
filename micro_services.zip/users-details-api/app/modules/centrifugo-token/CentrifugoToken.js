"use strict";

import Module from "../Module";
import { getModuleObject } from "../../utils/module.helper";

class CentrifugoToken extends Module {
  /*
  |--------------------------------------------------------------------------
  | CREATE Centrifugo Token CLASS AND METHOD INSTANCE
  |--------------------------------------------------------------------------
  */
  async execute(request, response, next) {
    const centrifugoTokenModule = await getModuleObject(request);
    return centrifugoTokenModule[request.body.action](
      request,
      response,
      next
    );
  }
  
  getModuleName() {
    return "Token";
  }
}

module.exports = CentrifugoToken;