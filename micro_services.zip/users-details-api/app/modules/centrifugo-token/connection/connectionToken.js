"use strict";

import { goodBye } from '../../../utils/http.helper';
import JwtProvider from '../../../providers/jwt.provider';
import config from '../../../../config/key/app/app.config';
import { SUCCESS } from '../../../constants/error.constant';
import { TOKEN_CREATED } from '../../../constants/error-message.constant';


class connectionToken {
  jwtAuthProvider = JwtProvider;
  /*
  |----------------------------
  | Constructor
  |----------------------------
  */
  constructor(jwtProvider = new JwtProvider()) {
    this.jwtAuthProvider = jwtProvider;
  }
  /*
  |----------------------------
  | Function to connectionToken Get user
  |----------------------------
  */
  async userConnectToken(request, response, next) {
    try {
      const tokenClaims = {
        sub: String(request.user.user_id),
        exp: Math.floor(Date.now() / 1000) + 120
      };
      const token = this.jwtAuthProvider.sign(tokenClaims, {}, config.centrifugo.secret_key);
      return goodBye(
        response, SUCCESS, TOKEN_CREATED, token
      );
    } catch (error) {
      next(new Error(`connectionToken : userConnectToken Method : ${error}`));
    }
  }
}

module.exports = connectionToken;
