"use strict";

import { goodBye } from '../../../utils/http.helper';
import { SUCCESS } from '../../../constants/error.constant';
import { ROOM_CREATED } from '../../../constants/error-message.constant';
import { fetchChatHistory } from '../../../repositories/chat-history.repositories';


class ChatHistory {
  /*
  |----------------------------
  | Function to create channel
  |----------------------------
  */
  async fetchChatHistory(request, response, next) {
    try {
      let reqBody = request.body.data;
      const data = await fetchChatHistory(request);
      return goodBye(
        response, SUCCESS, ROOM_CREATED, data
      );
    } catch (error) {
      next(new Error(`Authentication : register Method : ${error}`));
    }
  }
}

module.exports = ChatHistory;
