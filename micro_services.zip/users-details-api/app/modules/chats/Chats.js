"use strict";

import Module from "../Module";
import { getModuleObject } from "../../utils/module.helper";

class Chats extends Module {
  /*
  |--------------------------------------------------------------------------
  | CREATE Chats CLASS AND METHOD INSTANCE
  |--------------------------------------------------------------------------
  */
  async execute(request, response, next) {
    const chatsModule = await getModuleObject(request);
    return chatsModule[request.body.action](
      request,
      response,
      next
    );
  }
  
  getModuleName() {
    return "Chats";
  }
}

module.exports = Chats;
