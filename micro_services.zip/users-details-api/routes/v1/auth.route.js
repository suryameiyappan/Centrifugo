'use strict';

import { Router } from 'express';
import { execute } from './../../app/services/auth.service';

const router = Router();

router.post("/service", execute);

export default router;

