'use strict';

import express from 'express';
import authRouter from './v1/auth.route';
import UserDetailsRouter from './v1/user-deatil.route';
import { authMiddleware } from '../app/middleware/auth.middleware';

const app = express();

app.use('/authentication', authRouter);
app.use("/user-details", authMiddleware(), UserDetailsRouter);

export default app;