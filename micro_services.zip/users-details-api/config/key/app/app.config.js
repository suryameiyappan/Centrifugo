'use strict';

import dotenv from 'dotenv';
dotenv.config();

const config = {
	tmp: process.env.TMP || '/tmp', 
	node_env: process.env.NODE_ENV,
	port: process.env.PORT,
	storage: "../../../storage",
	server: {
		port: process.env.PORT,
		ip: process.env.IP || '0.0.0.0', 
	},
	redis: {
		host: process.env.REDIS_HOST,
		port: process.env.REDIS_PORT,
		db: process.env.REDIS_DB
	},
	pgsql: {
		username: process.env.PGSQL_USERNAME,
		password: process.env.PGSQL_PASSWORD,
		database: process.env.PGSQL_DATABASE,
		host: process.env.PGSQL_HOST,
		dialect: process.env.PGSQL
	},
	centrifugo: {
		secret_key: process.env.CENTRIFUGO_SECRET_KEY
	}
};

export default config;
