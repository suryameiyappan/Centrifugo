"use strict";

import redisConnection from "../db/redis.config";
import { moduleConfig } from "../../app/repositories/modules-config.repositories";


export const loadFactory = async (module, path) => {
  try {
    
    const key = `${path}:${module}`;
    const cachedRoute = (await redisConnection.get(key));

    if (!cachedRoute) {
      const route = (await moduleConfig(module, path));
      route ? (await redisConnection.set(key, JSON.stringify(route), { 'EX': 172800 , NX: true})) : "";
    }
    
    const routesObject = cachedRoute ? cachedRoute : (await redisConnection.get(key));
    return (JSON.parse(routesObject)?.product_class) ? (require(JSON.parse(routesObject).product_class)) : "";

  } catch (error) {
    console.log(`Modules Config : loadFactory Method : ${error}`);
    return null;
  }
};