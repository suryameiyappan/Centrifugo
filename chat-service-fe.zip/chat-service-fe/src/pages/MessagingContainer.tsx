import '../css/ChatRoom.css';
import React, {  useState } from "react";
import InboxPeople from "../component/InboxPeople";
import MessageInput from "../component/MessageInput";
import { restApiPost } from '../service/Api.service';
import MessageHistory from "../component/MessageHistory";

interface MessagingContainerProps {
  userRooms: any;
  channelName: (name: any) => void;
  messageDetails:any
  userInfo: any
}

const MessagingContainer: React.FC<MessagingContainerProps> = ({ userRooms, channelName, messageDetails, userInfo}) => {
  const [roomData, setRoomDetails] = useState<any>([]);
  const [chatDetails, setChatHistory] = useState<any>([]);
  const [currentUsersMessage, setCurrentUsersMessage] = useState<any>([]);
  
  const fetchChatHistory = async (roomData: any) => {
    const reqBody: any = {
      "module": "Chats",
      "module_code": "ChatHistory",
      "action": "fetchChatHistory",
      "data":{
        "room_id": roomData.id
      }
    };
    const userRooms = await restApiPost(reqBody, 'users/api/v1/user-details/service');
    setChatHistory(userRooms.data)
  };
      
  const roomDetails = (roomData: any) : void => {
    setRoomDetails(roomData)
    channelName(roomData)
    fetchChatHistory(roomData);
  };

  const appendCurrentMessage = (message: any) : void => {
    setCurrentUsersMessage(message)
  };

  return (
    <div className="container">
      <h3 className="text-center">Messaging</h3>
      <div className="messaging">
        <div className="inbox_msg">
          <InboxPeople userRoomData={userRooms} roomDetails={roomDetails}/>
          <div className="mesgs">
            <MessageHistory chatDetails={chatDetails} messageDetails={messageDetails} userInfo={userInfo} currentUsersMessage={currentUsersMessage}/>
            <MessageInput roomData={roomData} appendCurrentMessage={appendCurrentMessage}/>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MessagingContainer;
