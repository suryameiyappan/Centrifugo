import { createContext } from 'react';

const AuthContextProvider = createContext<any>({});

export default AuthContextProvider;
