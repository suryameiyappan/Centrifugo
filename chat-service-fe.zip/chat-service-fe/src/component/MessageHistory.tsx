import React, { useEffect, useRef } from "react";

interface MessagingContainerProps {
  chatDetails: any[];
  userInfo: any;
  messageDetails: any;
  currentUsersMessage: any;
}

const MessageHistory: React.FC<MessagingContainerProps> = ({ chatDetails, messageDetails, userInfo, currentUsersMessage }) => {
  const msgHistoryRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatDetails.forEach((msg) => {
      if (msg.type === 'outgoing') {
        outGoingMessage(msg);
      } else if (msg.type === 'incoming') {
        incommingMessage(msg);
      }
    });
  }, [chatDetails]);

  useEffect(() => {
    if (messageDetails.userId && messageDetails.userId != userInfo.id) {
      incommingMessage(messageDetails);
    }
  }, [messageDetails]);

  useEffect(() => {
    if (currentUsersMessage.content) {
      outGoingMessage(currentUsersMessage);
    }
  }, [currentUsersMessage]);

  const incommingMessage = (msg: any) => {
    if (msgHistoryRef.current) {
      const messageDiv = document.createElement('div');
      messageDiv.classList.add("incoming_msg");

      const imgContainer = document.createElement('div');
      imgContainer.classList.add('incoming_msg_img');
      const img = document.createElement('img');
      img.src = "https://ptetutorials.com/images/user-profile.png";
      img.alt = "User";
      imgContainer.appendChild(img);
      messageDiv.appendChild(imgContainer);

      const msgContentDiv = document.createElement('div');
      msgContentDiv.classList.add("received_msg");

      const msgText = document.createElement('p');
      msgText.textContent = msg.content;

      const timeSpan = document.createElement('span');
      timeSpan.classList.add('time_date');
      timeSpan.textContent = formatDate(msg.createdAt)
      msgContentDiv.appendChild(msgText);
      msgContentDiv.appendChild(timeSpan);
      messageDiv.appendChild(msgContentDiv);

      appendMessageAfterLastChild(messageDiv);
      scrollToBottom();
    }
  };

  const outGoingMessage = (msg: any) => {
    if (msgHistoryRef.current) {
      const messageDiv = document.createElement('div');
      messageDiv.classList.add("outgoing_msg");

      const msgContentDiv = document.createElement('div');
      msgContentDiv.classList.add("sent_msg");

      const msgText = document.createElement('p');
      msgText.textContent = msg.content;

      const timeSpan = document.createElement('span');
      timeSpan.classList.add('time_date');
      timeSpan.textContent = formatDate(msg.createdAt);

      msgContentDiv.appendChild(msgText);
      msgContentDiv.appendChild(timeSpan);
      messageDiv.appendChild(msgContentDiv);

      appendMessageAfterLastChild(messageDiv);
      scrollToBottom();
    }
  };

  const formatDate = (date: Date): string => {
    const currentTime: Date = new Date(date);
    return formatToSpecificTime(currentTime);
  };

  const formatToSpecificTime = (date: Date | string): string => {
    const newDate = new Date(date);
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true 
    };
    return newDate.toLocaleString('en-US', options);
  };
  

  const appendMessageAfterLastChild = (messageDiv: HTMLElement) => {
    if (msgHistoryRef.current) {
      const lastChild = msgHistoryRef.current.lastChild;
      if (lastChild) {
        msgHistoryRef.current.insertBefore(messageDiv, lastChild.nextSibling);
      } else {
        msgHistoryRef.current.appendChild(messageDiv);
      }
    }
  };

  const scrollToBottom = () => {
    if (msgHistoryRef.current) {
      msgHistoryRef.current.scrollTop = msgHistoryRef.current.scrollHeight;
    }
  };

  return <div className="msg_history" ref={msgHistoryRef}></div>;
};

export default MessageHistory;
