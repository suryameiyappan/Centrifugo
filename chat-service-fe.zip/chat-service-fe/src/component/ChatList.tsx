import React from "react";

interface MessagingContainerProps {
  userRooms: any;
  roomDetails: (userInfo: any) => void;
}

const ChatList: React.FC<MessagingContainerProps> = ({ userRooms, roomDetails }) => {

  const openRoom = (roomData: any) : void => {
    roomDetails(roomData);
  };

  return (
    <div className="inbox_chat">
      {userRooms.map((room: any, index: any) => (
        <div className="chat_list" key={index} onClick={() => openRoom(room.room)}>
          <div className="chat_people">
            <div className="chat_img">
              <img src='https://ptetutorials.com/images/user-profile.png' alt='demo' />
            </div>
            <div className="chat_ib">
              <h5>
                {room.room.name} <span className="chat_date">{room.room.createdAt}</span>
              </h5>
              {room.lastMessage ? <p>{room.lastMessage?.user_id}: {room.lastMessage?.content}</p> : ''}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ChatList;
