import React, { useState } from 'react';
import { restApiPost } from '../service/Api.service';

interface MessagingContainerProps {
  roomData: any
  appendCurrentMessage: (message: any) => void;
}

const MessageInput: React.FC<MessagingContainerProps> = ({ roomData, appendCurrentMessage }) => {
  const [message, setMessage] = useState('')

  const sendMessage = async () => {
      try {
        const reqBody: any = {
          "module": "Message",
          "module_code": "MessageDetails",
          "action": "sendMessage",
          "data":{
              "channel_id": roomData.id,
              "content": message
          }
        };
        const resData = await restApiPost(reqBody, 'message/api/v1/message/service');
        if (resData.code === 200) {
          const msgRequest: any = {
            content: message,
            createdAt: new Date()
          }
          setMessage('')
          appendCurrentMessage(msgRequest)
        } else {
           alert(resData.message);
        }
        
      } catch (err) {
        console.error('Login failed:', err);
      }
  };

  return (
    <div className="type_msg">
      <div className="input_msg_write">
        <input
          type="text"
          className="write_msg"
          placeholder="Type a message"
          value={message} onChange={(e) => setMessage(e.target.value)}
        />
        <button className="msg_send_btn" type="button" onClick={sendMessage}>
          <i className="fa fa-paper-plane-o" aria-hidden="true"></i>
        </button>
      </div>
    </div>
  );
};

export default MessageInput;
