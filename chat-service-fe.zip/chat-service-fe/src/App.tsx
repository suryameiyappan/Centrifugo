import { WS_ENDPOINT } from "./config/App.config";
import { restApiPost } from '../src/service/Api.service';
import React, { useEffect, useState, Suspense} from 'react';
import AuthContextProvider from './provider/AuthContext.provider';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import {
  Centrifuge, PublicationContext, SubscriptionStateContext,
  SubscribedContext, SubscriptionState
} from 'centrifuge';


const ChatLogin = React.lazy(() => import('./pages/ChatLogin'));
const MessagingContainer = React.lazy(() => import('./pages/MessagingContainer'));

const App: React.FC = () => {
  let localAuth: any = {};
  let sub2: any;
  let centrifuge: Centrifuge | any = null;
  if (sessionStorage.getItem("userData")) {
    localAuth = JSON.parse(sessionStorage.getItem("userData")!)
  }
  const [authenticated, setAuthenticated] = useState<boolean>(localAuth.id !== undefined)
  const [userInfo, setUserInfo] = useState<any>(localAuth)
  const [messageQueue, setMessageQueue] = useState<any>([]);
  const [userRoomsData, setUserRoomsData] = useState<any>([]);
  const [messageDetails, setMessageDetails] = useState<any>([]);
  const [channelData, setChannel] = useState<any>([]);

  useEffect(() => {
    const init = async () => {
      const personalChannel = 'personal:' + userInfo.id;

      const getPersonalChannelSubscriptionToken = async () => {
        const reqBody: any = {
          "module": "CentrifugoTokenConfig",
          "module_code": "SubToken",
          "action": "subscriptionToken",
          "data":{
            "channel": personalChannel
          }
        };
        const userRooms = await restApiPost(reqBody, 'users/api/v1/user-details/service');
        return userRooms.data
      }

      const getGroupChannelSubscriptionToken = async () => {
        const reqBody: any = {
          "module": "CentrifugoTokenConfig",
          "module_code": "SubToken",
          "action": "subscriptionToken",
          "data":{
            "channel": "group:news"
          }
        };
        const userRooms = await restApiPost(reqBody, 'users/api/v1/user-details/service');
        return userRooms.data
      }

      const getConnectionToken = async () => {
        const reqBody: any = {
          "module": "CentrifugoTokenConfig",
          "module_code": "ConToken",
          "action": "userConnectToken",
          "data":{}
        };
        const userRooms = await restApiPost(reqBody, 'users/api/v1/user-details/service');
        return userRooms.data
      }

      centrifuge = new Centrifuge(WS_ENDPOINT, {
        getToken: getConnectionToken,
        debug: true
      })
      centrifuge.connect()

      const sub = centrifuge.newSubscription(personalChannel, {
        getToken: getPersonalChannelSubscriptionToken
      })
      sub.on('publication', (ctx: PublicationContext) => {
        onPublication(ctx.data, 'personal')
      }).on('subscribed', (ctx: SubscribedContext) => {
        if (ctx.wasRecovering && !ctx.recovered) {
          console.log('State LOST - please reload the page')
        }
      })
      sub.on('state', (ctx: SubscriptionStateContext) => {
        if (ctx.newState == SubscriptionState.Subscribed) {
          console.log("connected");
        } else {
          console.log("disconnected");
        }
      })
      sub.subscribe()
    }

    if (authenticated) {
      init();
    }

    return () => {
      if (centrifuge) {
        console.log("disconnect Centrifuge")
        centrifuge.disconnect()
      }
    }
  }, [userInfo])

  useEffect(() => {
    const fetchUserRooms = async () => {
      const reqBody: any = {
        "module": "Room",
        "module_code": "UserRooms",
        "action": "listUserRoomDetails",
        "data":{}
      };
      const userRooms = await restApiPost(reqBody, 'users/api/v1/user-details/service');
      setUserRoomsData(userRooms.data)
    }
    if (authenticated) {
      fetchUserRooms();
    }
  }, [userInfo]);

  useEffect(() => {
    const processMessageAdded = async (body: any) => {
      setMessageDetails(body);
    }

    const processMessage = async () => {
      const message: any = messageQueue;
      switch (message.type) {
        case 'message_added': {
          await processMessageAdded(message.body);
          break
        }
        default:
          console.log('unsupported message type')
      }
    }
    processMessage();
  }, [messageQueue]);

  const onPublication = async (publication: any, chatType: string) => {
    // const presence = await centrifuge.presence("group:news");
    // console.log(`Presence for channel "group:news":`, presence);
    console.log(publication);
    setTimeout(() => {
      chatType == 'personal' ? setMessageQueue(publication) : alert(chatType);
    }, 1000);
    
  };

  const onLoginSuccess = async (userInfo: any) => {
    sessionStorage.setItem("authToken", userInfo.data.token);
    sessionStorage.setItem("userData", JSON.stringify(userInfo.data.user));
    setAuthenticated(true);
    setUserInfo(userInfo.data.user);
  };

  const channelDetails = (channel: any) => {
    setChannel(channel)
  }

  return (
    <AuthContextProvider.Provider value={userInfo}>
      <Router>
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
        {authenticated ? (
            <Route path="/chat-room" element={<MessagingContainer userRooms={userRoomsData} channelName={channelDetails} messageDetails={messageDetails} userInfo={userInfo}/>} />
        ) : (
            <Route path="/login" element={<ChatLogin onSuccess={onLoginSuccess} />} />
        )}
        <Route path="*" element={<Navigate to={authenticated ? "/chat-room" : "/login"} replace />} />
        </Routes>
        </Suspense>
    </Router>
    </AuthContextProvider.Provider>
  );
};

export default App;