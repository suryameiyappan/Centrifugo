import axios from "axios";
import { API_ENDPOINT_BASE } from "../config/App.config";

export const restApiPost = async (reqData: string, endPoint: string) => {
  let token: string | null = sessionStorage.getItem('authToken');
  
  try {
    const response = await axios.post(`${API_ENDPOINT_BASE}${endPoint}`, reqData, {
      headers: {
        Authorization: token ? `Bearer ${token}` : '',
        'api-version': 'v1',
      }
    });
    return response.data;
  } catch (error: any) {
    if (error.response) {
      const { status } = error.response;
            if (status === 401 || status === 403) {
              sessionStorage.clear();
              window.location.href = '/login';
      }
    } else {
      console.error('An unknown error occurred:', error);
    }
    throw error;
  }
}
