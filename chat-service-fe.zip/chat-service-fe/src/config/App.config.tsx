export const LOCAL_STORAGE_AUTH_KEY = 'auth'
export const API_ENDPOINT_BASE = "http://chat-service-api.dv/";
export const WS_ENDPOINT = 'ws://localhost:8000/connection/websocket'
